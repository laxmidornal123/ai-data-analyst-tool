import pandas as pd


def analyze_dataset(df):

    result = {

        "date_col": None,
        "amount_col": None,
        "customer_col": None,
        "product_col": None,
        "category_col": None,

        "numeric_cols": [],
        "categorical_cols": [],

        "dataset_type": "Generic"
    }

    # -----------------------
    # Numeric Columns
    # -----------------------

    for col in df.select_dtypes(include='number').columns:

        col_lower = col.lower()

        if (
            "id" not in col_lower
            and "code" not in col_lower
            and "roll" not in col_lower
        ):
            result["numeric_cols"].append(col)

    # -----------------------
    # Categorical Columns
    # -----------------------

    for col in df.columns:

        if df[col].dtype == "object":

            result["categorical_cols"].append(col)

    # -----------------------
    # Detect Important Columns
    # -----------------------

    for col in df.columns:

        col_lower = col.lower()

        # Date Column

        if (
            result["date_col"] is None
            and any(word in col_lower for word in [
                "date",
                "time",
                "month",
                "year"
            ])
        ):
            result["date_col"] = col

        # Customer Column

        if (
            result["customer_col"] is None
            and any(word in col_lower for word in [
                "customer",
                "student",
                "employee",
                "patient",
                "client",
                "user"
            ])
        ):
            result["customer_col"] = col

        # Product Column

        if (
            result["product_col"] is None
            and any(word in col_lower for word in [
                "product",
                "food",
                "item",
                "subject",
                "dish"
            ])
        ):
            result["product_col"] = col

        # Category Column

        if (
            result["category_col"] is None
            and any(word in col_lower for word in [
                "category",
                "department",
                "branch",
                "city",
                "region",
                "type"
            ])
        ):
            result["category_col"] = col

    # -----------------------
    # Amount Column Priority
    # -----------------------

    amount_priority = [
        "total_amount",
        "amount",
        "revenue",
        "sales",
        "price",
        "profit",
        "salary",
        "marks"
    ]

    for keyword in amount_priority:

        for col in df.columns:

            if keyword in col.lower():

                result["amount_col"] = col
                break

        if result["amount_col"]:
            break

    # -----------------------
    # Fallback Amount Column
    # -----------------------

    if result["amount_col"] is None:

        if len(result["numeric_cols"]) > 0:

            result["amount_col"] = result["numeric_cols"][0]

        # -----------------------
    # Dataset Type Detection
    # -----------------------

    columns_text = " ".join(
        [c.lower() for c in df.columns]
    )

    if any(x in columns_text for x in [
        "patient",
        "doctor",
        "disease",
        "treatment",
        "hospital"
    ]):
        result["dataset_type"] = "Hospital"

    elif any(x in columns_text for x in [
        "student",
        "marks",
        "attendance",
        "subject",
        "grade"
    ]):
        result["dataset_type"] = "Student"

    elif any(x in columns_text for x in [
        "employee",
        "salary",
        "department",
        "designation"
    ]):
        result["dataset_type"] = "HR"

    elif any(x in columns_text for x in [
        "sales",
        "profit",
        "product",
        "quantity",
        "revenue"
    ]):
        result["dataset_type"] = "Sales"

    elif any(x in columns_text for x in [
        "restaurant",
        "food",
        "food_item",
        "payment_method",
        "rating"
    ]):
        result["dataset_type"] = "Zomato"

    else:
        result["dataset_type"] = "Generic"

    # -----------------------
    # Fallback Category Column
    # -----------------------

    if result["category_col"] is None:

        if len(result["categorical_cols"]) > 0:

            result["category_col"] = result["categorical_cols"][0]

    return result
    # -----------------------
    # Fallback Category Column
    # -----------------------

    if result["category_col"] is None:

        if len(result["categorical_cols"]) > 0:

            result["category_col"] = result["categorical_cols"][0]

    return result