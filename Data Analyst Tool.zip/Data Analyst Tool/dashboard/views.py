from django.shortcuts import render, redirect
from django.contrib.auth import logout

from .models import Dataset
from .analyzer import analyze_dataset
from reportlab.platypus import Image
import pandas as pd
import plotly.express as px
import plotly.offline as opy
from django.http import HttpResponse
from django.core.mail import EmailMessage
from django.contrib.auth.models import User
from django.contrib import messages

def dashboard_view(request):

    file_path = request.session.get("file_path")

    if not file_path:
        return redirect("upload")

    try:

        if file_path.endswith(".csv"):

            try:
                df = pd.read_csv(file_path)

                if len(df.columns) == 1:
                    df = pd.read_csv(
                        file_path,
                        sep="\t"
                    )

            except:
                df = pd.read_csv(
                    file_path,
                    sep="\t"
                )

        elif file_path.endswith(".xlsx"):

            df = pd.read_excel(file_path)

        else:
            return redirect("upload")

    except Exception as e:

        print("File Error:", e)
        return redirect("upload")

    print("Shape:", df.shape)
    print("Columns:", df.columns.tolist())

    analysis = analyze_dataset(df)

    dataset_type = analysis.get("dataset_type", "Generic")

    date_col = analysis.get("date_col")
    amount_col = analysis.get("amount_col")
    customer_col = analysis.get("customer_col")
    product_col = analysis.get("product_col")
    category_col = analysis.get("category_col")

    numeric_cols = analysis.get(
        "numeric_cols",
        []
    )

    categorical_cols = analysis.get(
        "categorical_cols",
        []
    )

    print("Dataset Type:", dataset_type)
    print("Amount:", amount_col)
    print("Category:", category_col)
    print("Product:", product_col)
    print("Date:", date_col)

    if amount_col and amount_col in df.columns:

        df[amount_col] = pd.to_numeric(
            df[amount_col],
            errors="coerce"
        )

    rows = len(df)
    columns = len(df.columns)

    missing = int(
        df.isnull().sum().sum()
    )

    duplicates = int(
        df.duplicated().sum()
    )

    columns_list = df.columns.tolist()

    # =====================
    # KPI CARDS
    # =====================

    kpis = {
        "Rows": rows,
        "Columns": columns,
        "Missing Values": missing,
        "Duplicates": duplicates,
    }

    if amount_col and amount_col in df.columns:

        kpis["Total"] = round(
            float(
                df[amount_col]
                .fillna(0)
                .sum()
            ),
            2
        )

        kpis["Average"] = round(
            float(
                df[amount_col]
                .fillna(0)
                .mean()
            ),
            2
        )

        kpis["Maximum"] = round(
            float(
                df[amount_col]
                .fillna(0)
                .max()
            ),
            2
        )
    # =====================
    # AI INSIGHTS
    # =====================

    insights = []

    insights.append(
        f"Dataset Type: {dataset_type}"
    )

    insights.append(
        f"Dataset contains {rows} rows and {columns} columns."
    )

    insights.append(
        f"Missing Values: {missing}"
    )

    insights.append(
        f"Duplicate Rows: {duplicates}"
    )

    # =====================
    # TABLE
    # =====================

    table = df.head(20).to_html(
        classes="table",
        index=False
    )

    # =====================
    # CHARTS
    # =====================

    bar_chart = ""
    pie_chart = ""
    line_chart = ""
    scatter_chart = ""
    top_category_chart = ""

    # BAR CHART

    try:

        if category_col and amount_col:

            chart_data = (
                df.groupby(category_col)[amount_col]
                .sum()
                .reset_index()
                .sort_values(
                    amount_col,
                    ascending=False
                )
                .head(10)
            )
            print(chart_data.head())
            print(chart_data.columns.tolist())
            fig = px.bar(
               chart_data,
               x=chart_data.columns[0],
               y=chart_data.columns[1],
               title="Bar Chart"
            )
            bar_chart = opy.plot(
                fig,
                auto_open=False,
                output_type="div",
                include_plotlyjs=False
            )
            fig.write_image("bar_chart.png")

    except Exception as e:

        print("Bar Chart Error:", e)

    # PIE CHART

    try:

        if category_col:

            pie_data = (
                df[category_col]
                .value_counts()
                .head(10)
                .reset_index()
            )

            pie_data.columns = [
                category_col,
                "Count"
            ]

            fig = px.pie(
                pie_data,
                names=category_col,
                values="Count",
                hole=0.4,
                title=f"{category_col} Distribution"
            )

            pie_chart = opy.plot(
                fig,
                auto_open=False,
                output_type="div",
                include_plotlyjs=False
            )
            fig.write_image("pie_chart.png")

    except Exception as e:

        print("Pie Chart Error:", e)

    # LINE CHART

    try:

        if date_col and amount_col:

            df[date_col] = pd.to_datetime(
                df[date_col],
                errors="coerce"
            )

            line_data = (
                df.groupby(date_col)[amount_col]
                .sum()
                .reset_index()
            )

            fig = px.line(
                line_data,
                x=date_col,
                y=amount_col,
                title=f"{amount_col} Trend"
            )

            line_chart = opy.plot(
                fig,
                auto_open=False,
                output_type="div",
                include_plotlyjs=False
            )
            fig.write_image("line_chart.png")

    except Exception as e:

        print("Line Chart Error:", e)

    # SCATTER CHART

    try:

        if len(numeric_cols) >= 2:

            fig = px.scatter(
                df,
                x=numeric_cols[0],
                y=numeric_cols[1],
                title=f"{numeric_cols[0]} vs {numeric_cols[1]}"
            )

            scatter_chart = opy.plot(
                fig,
                auto_open=False,
                output_type="div",
                include_plotlyjs=False
            )
            fig.write_image("scatter_chart.png")

    except Exception as e:

        print("Scatter Error:", e)

    # TOP PRODUCT CHART

    try:

        if product_col:

            top_data = (
                df[product_col]
                .value_counts()
                .head(10)
                .reset_index()
            )

            top_data.columns = [
                product_col,
                "Count"
            ]

            fig = px.bar(
                top_data,
                x=product_col,
                y="Count",
                title=f"Top {product_col}"
            )

            top_category_chart = opy.plot(
                fig,
                auto_open=False,
                output_type="div",
                include_plotlyjs=False
            )
            fig.write_image("top_product_chart.png")

    except Exception as e:

        print("Top Product Error:", e)
    print("Bar Chart Length:", len(bar_chart))
    print("Pie Chart Length:", len(pie_chart))
    print("Top Product Length:", len(top_category_chart))
    context = {

        "dataset_type": dataset_type,

        "rows": rows,
        "columns": columns,
        "missing": missing,
        "duplicates": duplicates,

        "columns_list": columns_list,

        "kpis": kpis,
        "insights": insights,

        "table": table,

        "bar_chart": bar_chart,
        "pie_chart": pie_chart,
        "line_chart": line_chart,
        "scatter_chart": scatter_chart,
        "top_category_chart": top_category_chart,
    }

    return render(
        request,
        "dashboard.html",
        context
    )


def login_view(request):

    if request.method == "POST":

        username = request.POST.get("username")
        password = request.POST.get("password")

        # Temporary login
        return redirect("upload")

    return render(
        request,
        "login.html"
    )


def register_view(request):

    if request.method == "POST":

        username = request.POST.get("username")
        email = request.POST.get("email")
        password = request.POST.get("password")

        # Username Exists
        if User.objects.filter(username=username).exists():

            return render(
                request,
                "register.html",
                {
                    "alert_message":
                    "Username already exists!"
                }
            )

        # Email Exists
        if User.objects.filter(email=email).exists():

            return render(
                request,
                "register.html",
                {
                    "alert_message":
                    "Email already registered!"
                }
            )

        User.objects.create_user(
            username=username,
            email=email,
            password=password
        )

        return render(
            request,
            "register.html",
            {
                "success_message":
                "Registration Successful!"
            }
        )

    return render(
        request,
        "register.html"
    )
def upload_view(request):

    if request.method == "POST":

        uploaded_file = request.FILES.get(
            "csv_file"
        )

        if uploaded_file:

            dataset = Dataset.objects.create(
                file=uploaded_file
            )

            request.session[
                "file_path"
            ] = dataset.file.path

            return redirect(
                "dashboard"
            )

    return render(
        request,
        "upload.html"
    )


def logout_view(request):

    logout(request)

    return redirect(
        "login"
    )
from reportlab.platypus import (
    SimpleDocTemplate,
    Paragraph,
    Spacer
)

from reportlab.lib.styles import getSampleStyleSheet
def send_dashboard_email(request):

    from django.http import HttpResponse
    from django.core.mail import EmailMessage

    from reportlab.platypus import (
        SimpleDocTemplate,
        Paragraph,
        Spacer
    )

    from reportlab.lib.styles import (
        getSampleStyleSheet
    )

    file_path = request.session.get("file_path")

    if not file_path:
        return HttpResponse(
            "No dataset uploaded."
        )

    receiver_email = request.POST.get(
        "receiver_email"
    )

    if not receiver_email:
        return HttpResponse(
            "Please enter an email address."
        )

    # Load Dataset

    try:

        if file_path.endswith(".csv"):

            try:

                df = pd.read_csv(file_path)

                if len(df.columns) == 1:

                    df = pd.read_csv(
                        file_path,
                        sep="\t"
                    )

            except:

                df = pd.read_csv(
                    file_path,
                    sep="\t"
                )

        else:

            df = pd.read_excel(
                file_path
            )

    except Exception as e:

        return HttpResponse(
            f"Error reading file: {e}"
        )

    # Analyze Dataset

    analysis = analyze_dataset(df)

    dataset_type = analysis.get(
        "dataset_type",
        "Generic"
    )

    amount_col = analysis.get(
        "amount_col"
    )

    rows = len(df)
    columns = len(df.columns)

    missing = int(
        df.isnull().sum().sum()
    )

    duplicates = int(
        df.duplicated().sum()
    )

    # KPI Values

    total_value = 0
    avg_value = 0
    max_value = 0

    if amount_col and amount_col in df.columns:

        df[amount_col] = pd.to_numeric(
            df[amount_col],
            errors="coerce"
        )

        total_value = round(
            float(
                df[amount_col]
                .fillna(0)
                .sum()
            ),
            2
        )

        avg_value = round(
            float(
                df[amount_col]
                .fillna(0)
                .mean()
            ),
            2
        )

        max_value = round(
            float(
                df[amount_col]
                .fillna(0)
                .max()
            ),
            2
        )

    # Create PDF

    pdf_path = "dashboard_report.pdf"

    doc = SimpleDocTemplate(
        pdf_path
    )

    styles = getSampleStyleSheet()

    elements = []

    elements.append(
        Paragraph(
            "AI Data Analyst Dashboard Report",
            styles["Title"]
        )
    )

    elements.append(
        Spacer(1, 20)
    )

    # Dataset Information

    elements.append(
        Paragraph(
            "Dataset Information",
            styles["Heading2"]
        )
    )

    elements.append(
        Paragraph(
            f"Dataset Type: {dataset_type}",
            styles["Normal"]
        )
    )

    elements.append(
        Paragraph(
            f"Rows: {rows}",
            styles["Normal"]
        )
    )

    elements.append(
        Paragraph(
            f"Columns: {columns}",
            styles["Normal"]
        )
    )

    elements.append(
        Paragraph(
            f"Missing Values: {missing}",
            styles["Normal"]
        )
    )

    elements.append(
        Paragraph(
            f"Duplicate Rows: {duplicates}",
            styles["Normal"]
        )
    )

    elements.append(
        Spacer(1, 20)
    )

    # KPI Section

    elements.append(
        Paragraph(
            "KPI Summary",
            styles["Heading2"]
        )
    )

    elements.append(
        Paragraph(
            f"Total Value: {total_value}",
            styles["Normal"]
        )
    )

    elements.append(
        Paragraph(
            f"Average Value: {avg_value}",
            styles["Normal"]
        )
    )

    elements.append(
        Paragraph(
            f"Maximum Value: {max_value}",
            styles["Normal"]
        )
    )

    elements.append(
        Spacer(1, 20)
    )

    # Dataset Columns

    
    # Build PDF
    elements.append(
    Paragraph(
        "Dashboard Charts",
        styles["Heading2"]
    )
)

    elements.append(
    Image(
        "bar_chart.png",
        width=450,
        height=250
    )
)

    elements.append(
    Image(
        "pie_chart.png",
        width=450,
        height=250
    )
)

    elements.append(
    Image(
        "scatter_chart.png",
        width=450,
        height=250
    )
)
    doc.build(elements)

    # Send Email

    email = EmailMessage(
        subject="AI Dashboard Report",
        body="Please find the attached dashboard report.",
        from_email="yourgmail@gmail.com",
        to=[receiver_email]
    )
    email.attach_file(
        pdf_path
    )

    email.send()

    messages.success(
        request,
        f"Dashboard report sent successfully to {receiver_email}"
    )

    return redirect("dashboard")  
def clear_dashboard(request):

    request.session.pop(
        "file_path",
        None
    )

    return redirect(
        "upload"
    )
def settings_view(request):
    return render(
        request,
        "settings.html"
    )