from django.urls import path
from . import views

urlpatterns = [

    path('', views.login_view, name='login'),

    path(
        'register/',
        views.register_view,
        name='register'
    ),
    path(
        'dashboard/',
        views.dashboard_view,
        name='dashboard'
    ),

    path(
        'upload/',
        views.upload_view,
        name='upload'
    ),

    path(
        'logout/',
        views.logout_view,
        name='logout'
    ),
    path(
    "send-email/",
    views.send_dashboard_email,
    name="send_email"
),
    path(
    "clear-dashboard/",
    views.clear_dashboard,
    name="clear_dashboard"
),
    path(
    "settings/",
    views.settings_view,
    name="settings"
),
]