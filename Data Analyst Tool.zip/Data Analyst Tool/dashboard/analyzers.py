import pandas as pd


def analyze_dataset(df):

    result = {

        "date_col": None,
        "amount_col": None,
        "customer_col": None,
        "product_col": None,
        "category_col": None,

        "numeric_cols": [],
        "categorical_cols": [],

        "dataset_type": "Generic"
    }

    # -----------------------
    # Numeric Columns
    # -----------------------

    for col in df.select_dtypes(include='number').columns:

        col_lower = col.lower()

        if (
            "id" not in col_lower
            and "code" not in col_lower
            and "roll" not in col_lower
        ):

            result["numeric_cols"].append(col)

    # -----------------------
    # Categorical Columns
    # -----------------------

    for col in df.columns:

        if df[col].dtype == "object":

            result["categorical_cols"].append(col)

    # -----------------------
    # Detect Important Columns
    # -----------------------

    for col in df.columns:

        col_lower = col.lower()

        # Date

        if any(word in col_lower for word in [
            "date",
            "time",
            "month",
            "year"
        ]):

            result["date_col"] = col

        # Amount

        if any(word in col_lower for word in [
            "amount",
            "sales",
            "revenue",
            "price",
            "profit",
            "marks",
            "salary"
        ]):

            result["amount_col"] = col

        # Customer

        if any(word in col_lower for word in [
            "customer",
            "student",
            "employee",
            "patient"
        ]):

            result["customer_col"] = col

        # Product

        if any(word in col_lower for word in [
            "product",
            "food",
            "item",
            "subject"
        ]):

            result["product_col"] = col

        # Category

        if any(word in col_lower for word in [
            "category",
            "department",
            "branch",
            "city",
            "region"
        ]):

            result["category_col"] = col

    # -----------------------
    # Dataset Type Detection
    # -----------------------

    columns_text = " ".join(
        [c.lower() for c in df.columns]
    )

    if any(x in columns_text for x in [
        "food",
        "restaurant",
        "order",
        "customer"
    ]):
        result["dataset_type"] = "Zomato"

    elif any(x in columns_text for x in [
        "student",
        "marks",
        "attendance"
    ]):
        result["dataset_type"] = "Student"

    elif any(x in columns_text for x in [
        "employee",
        "salary",
        "department"
    ]):
        result["dataset_type"] = "HR"

    elif any(x in columns_text for x in [
        "patient",
        "doctor",
        "disease"
    ]):
        result["dataset_type"] = "Hospital"

    elif any(x in columns_text for x in [
        "sales",
        "profit",
        "product"
    ]):
        result["dataset_type"] = "Sales"

    return result