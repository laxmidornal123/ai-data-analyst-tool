def detect_dataset(df):

    columns = [c.lower() for c in df.columns]

    scores = {
        "student": 0,
        "sales": 0,
        "hr": 0,
        "hospital": 0
    }

    student_keywords = [
        "student", "marks", "attendance",
        "semester", "grade"
    ]

    sales_keywords = [
        "sales", "profit", "revenue",
        "product", "amount"
    ]

    hr_keywords = [
        "employee", "salary",
        "department", "experience"
    ]

    hospital_keywords = [
        "patient", "doctor",
        "disease", "bill"
    ]

    for col in columns:

        for word in student_keywords:
            if word in col:
                scores["student"] += 1

        for word in sales_keywords:
            if word in col:
                scores["sales"] += 1

        for word in hr_keywords:
            if word in col:
                scores["hr"] += 1

        for word in hospital_keywords:
            if word in col:
                scores["hospital"] += 1

    return max(scores, key=scores.get)