def get_hr_insights(df):

    insights = []

    insights.append(
        f"Total Employees: {len(df)}"
    )

    return insights