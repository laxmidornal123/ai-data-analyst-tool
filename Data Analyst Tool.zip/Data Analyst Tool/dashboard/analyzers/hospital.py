def get_hospital_insights(df):

    insights = []

    insights.append(
        f"Total Patients: {len(df)}"
    )

    return insights