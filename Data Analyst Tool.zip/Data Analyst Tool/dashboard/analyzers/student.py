def get_student_insights(df):

    insights = []

    insights.append(
        f"Total Students: {len(df)}"
    )

    for col in df.select_dtypes(include='number').columns:

        insights.append(
            f"{col} Average = {df[col].mean():.2f}"
        )

    return insights