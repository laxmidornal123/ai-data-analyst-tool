def get_sales_insights(df):

    insights = []

    for col in df.select_dtypes(include='number').columns:

        insights.append(
            f"{col} Total = {df[col].sum():.2f}"
        )

    return insights